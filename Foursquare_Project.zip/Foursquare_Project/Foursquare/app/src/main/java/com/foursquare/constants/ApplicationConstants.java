package com.foursquare.constants;

enum SORT_FILTER {
    RATING, DISTANCE, POPULAR;
}

enum TIER_FILTER {
    LOW_PRICE, MODERATE_PRICE, HIGH_PRICE, VERY_HIGH_PRICE;
}

public class ApplicationConstants {

    public enum SIGNINTYPE { GOOGLE_SIGNIN, NORMAL_SIGNIN, FACEBOOK_SIGNIN}
    public static SIGNINTYPE SIGN_IN_TYPE = SIGNINTYPE.NORMAL_SIGNIN;
    public static String IMAGE_URL = "imageurl";
    public static String ACCOUNT_HOLDER_NAME = "username";
    public static String ACCOUNT_HOLDER_EMAIL = "email";
    public static String USER_ICON_SIZE = "100x100";
    public static String GOOGLE = "google";
    public static String FACEBOOK = "facebook";
    public static String NORMAL = "normal";
}
