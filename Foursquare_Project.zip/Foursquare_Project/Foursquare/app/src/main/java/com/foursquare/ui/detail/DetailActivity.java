package com.foursquare.ui.detail;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;
import com.foursquare.constants.BundleConstants;
import com.foursquare.networks.map.GPSTracker;
import com.foursquare.networks.model.sub.Venue;
import com.foursquare.networks.model.venueDetail.VenueDetails;
import com.foursquare.networks.retrofit.ApiCall;
import com.foursquare.networks.retrofit.ApiInterface;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.foursquare.constants.ApiConstants.LAT_LONG_NY;
import static com.foursquare.constants.ApiConstants.OAUTH_TOKEN;
import static com.foursquare.constants.ApiConstants.V;
import static com.foursquare.constants.BundleConstants.VENUE_ID;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;
import static com.foursquare.utils.Util.isNetworkConnectionAvailable;

public class DetailActivity extends AppCompatActivity implements Callback<VenueDetails>, View.OnClickListener, OnMapReadyCallback {
    public RatingBar mRating;
    public Button mSubmitButton;
    private Toolbar mToolbar;
    private ImageView mToolbarImage;
    private TextView mToolbarTitle;
    private TextView mVenueTitle;
    private RatingBar mRatingBar;
    private TextView mDescription;
    private TextView mVenueAddress;
    private View mErrorLayout;
    private TextView mErrorTextView;
    private ProgressBar mLoadingProgressBar;
    private Venue mVenueDetail;
    private ImageView mImageLayout;
    private String mVenueId;
    private String mVenueName;
    private Button mAddReviewButton;
    private LinearLayout mPhotoLayout;
    private LinearLayout mReviewLayout;
    private LinearLayout mRatingLayout;
    private float mRatingValue;
    private String mRatingColor;
    private double mVenueLatitude = 0.0d;
    private double mVenueLongitude = 0.0d;
    private GoogleMap mGoogleMap;
    private MapView mMapView;
    private GPSTracker gps;
    private Dialog mRatingDialog;
    private boolean mMapReady = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        initViews();
        setToolbar();
    }

    private void setToolbar() {
        mToolbarImage.setVisibility(View.GONE);
        mToolbarTitle.setVisibility(View.VISIBLE);
        mToolbarTitle.setText(mVenueName);
    }

    private void getVenueId() {
        mVenueId = getIntent().getStringExtra(VENUE_ID);
        mVenueName = getIntent().getStringExtra(VENUE_NAME);
    }

    private void initViews() {
        initToolbar();
        initViewVariables();
        getVenueId();
        fetchVenueDetail();
        initMapView();
        onClickEvents();
    }

    private void onClickEvents() {
        mPhotoLayout.setOnClickListener(this);
        mReviewLayout.setOnClickListener(this);
        mAddReviewButton.setOnClickListener(this);
        mRatingLayout.setOnClickListener(this);
    }

    private void initMapView() {
        if (mMapView != null) {
            mMapView.onCreate(null);
            mMapView.getMapAsync(this);
        }
    }

    private void fetchVenueDetail() {
        if (isNetworkConnectionAvailable(Objects.requireNonNull(getApplicationContext()))) {
            displayError(R.string.loading, true);

            ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
            Call<VenueDetails> venueDetailsCall = apiInterface.getVenueDetail(mVenueId, OAUTH_TOKEN, V, LAT_LONG_NY);
            venueDetailsCall.enqueue(this);
        } else {
            displayError(R.string.network_error, false);
        }
    }

    private void displayError(int errorStringId, Boolean bool) {
        mErrorLayout.setVisibility(View.VISIBLE);
        mErrorTextView.setText(errorStringId);
        if (!bool) {
            mLoadingProgressBar.setVisibility(View.GONE);
        }
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);

        mToolbarImage = mToolbar.findViewById(R.id.toolbar_image);
        mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void errorStatusInit() {
        mErrorLayout = findViewById(R.id.error_layout);
        mErrorTextView = mErrorLayout.findViewById(R.id.error_message);
        mLoadingProgressBar = mErrorLayout.findViewById(R.id.progressBar);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mMapView.onResume();
    }

    @Override
    protected void onPause() {
        mMapView.onPause();
        super.onPause();
    }

    private void initViewVariables() {
        venueDetailsInit();
        errorStatusInit();
        mImageLayout = findViewById(R.id.image_layout);
        mPhotoLayout = findViewById(R.id.photo_layout);
        mReviewLayout = findViewById(R.id.layout_review);
        mRatingLayout = findViewById(R.id.rating_layout);
        View mMapLayout = findViewById(R.id.map_layout);
        mMapView = mMapLayout.findViewById(R.id.map);
        mRatingDialog = new Dialog(DetailActivity.this);
    }

    private void venueDetailsInit() {
        mVenueTitle = findViewById(R.id.venue_title);
        mRatingBar = findViewById(R.id.rating);
        mDescription = findViewById(R.id.description);
        mVenueAddress = findViewById(R.id.venue_address);
        mAddReviewButton = findViewById(R.id.add_review);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu_share_favourite, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {

            case R.id.share:
                intent = new Intent(android.content.Intent.ACTION_SEND);
                intent.setType(getString(R.string.mime_type_text_plain));
                intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_value));
                startActivity(Intent.createChooser(intent, getString(R.string.share_via)));
                return true;

            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResponse(Call<VenueDetails> call, Response<VenueDetails> response) {
        if (response.isSuccessful() && response.body() != null) {
            mErrorLayout.setVisibility(View.GONE);
            mVenueDetail = response.body().getResponse().getVenue();
            setVenueDetail();

        } else {
            displayError(R.string.failed_to_fetch_data, false);
        }
    }

    private void setVenueDetail() {
        String toastDisplay = "";
        mVenueTitle.setText(mVenueDetail.getName());

        setVenueDescription();
        setVenueRating();
        setVenueRatingColor();
        toastDisplay = setVenueBackdrop(toastDisplay);
        setVenueAddress();
        getVenueLocation();

        if (!TextUtils.isEmpty(toastDisplay))
            Toast.makeText(this, toastDisplay, Toast.LENGTH_LONG).show();
    }

    private void setVenueAddress() {
        if (mVenueDetail.getLocation().getFormattedAddress() != null) {
            StringBuilder venueAdress = new StringBuilder();
            List<String> address = new ArrayList<>(mVenueDetail.getLocation().getFormattedAddress());
            for (int i = 0; i < address.size(); i++) {
                venueAdress.append(address.get(i)).append("\n");
            }
            mVenueAddress.setText(venueAdress);

        } else {
            mVenueAddress.setText(R.string.address_not_found);
        }
    }

    private String setVenueBackdrop(String toastDisplay) {
        if ((mVenueDetail.getBestPhoto() != null)) {
            if (!TextUtils.isEmpty(mVenueDetail.getBestPhoto().getPrefix()) || !TextUtils.isEmpty(mVenueDetail.getBestPhoto().getSuffix())) {
                Glide.with(mImageLayout.getContext()).load(mVenueDetail.getBestPhoto().getPrefix() + "200x200" + mVenueDetail.getBestPhoto().getSuffix()).apply(new RequestOptions().placeholder(R.drawable.background)).into(mImageLayout);
            }
        } else {
            toastDisplay = getString(R.string.could_not_load_image);
            mImageLayout.setBackground(getResources().getDrawable(R.drawable.image_placeholder));
        }
        return toastDisplay;
    }

    private void setVenueRatingColor() {
        if (mVenueDetail.getRatingColor() != null) {
            mRatingColor = mVenueDetail.getRatingColor();

        } else {
            mRatingColor = getString(R.string.color_green);
        }
    }

    private void setVenueRating() {
        if (mVenueDetail.getRating() != null) {
            mRatingValue = Float.parseFloat(mVenueDetail.getRating().toString());
            mRatingBar.setVisibility(View.VISIBLE);
            mRatingBar.setRating(mRatingValue / 2);
        } else {
            mRatingBar.setVisibility(View.GONE);
            mRatingValue = 0.0f;
        }
    }

    private void setVenueDescription() {
        if (mVenueDetail.getPage() != null && mVenueDetail.getPage().getPageInfo() != null && mVenueDetail.getPage().getPageInfo().getDescription() != null) {
            mDescription.setText(mVenueDetail.getPage().getPageInfo().getDescription());
        } else {
            mDescription.setText(R.string.no_description);
        }
    }

    private void getVenueLocation() {
        if (mVenueDetail.getLocation() != null) {
            mVenueLatitude = mVenueDetail.getLocation().getLat();
            mVenueLongitude = mVenueDetail.getLocation().getLng();
            if (mMapReady)
                setVenueLocation();
        } else {
            mVenueLatitude = 0.0d;
            mVenueLongitude = 0.0d;
        }

    }

    private void setVenueLocation() {
        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        mGoogleMap.addMarker(new MarkerOptions().position(new LatLng(mVenueLatitude, mVenueLongitude)).title(mVenueName).snippet("Feel the air around you!!!"));
        CameraPosition venue = CameraPosition.builder().target(new LatLng(mVenueLatitude, mVenueLongitude)).zoom(15).bearing(0).tilt(90).build();
        mGoogleMap.moveCamera(CameraUpdateFactory.newCameraPosition(venue));
    }

    @Override
    public void onFailure(Call<VenueDetails> call, Throwable t) {
        displayError(R.string.failed_to_fetch_data, false);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.photo_layout:
                intent = new Intent(this, PhotoGridActivity.class);
                putDataToIntent(intent);
                startActivity(intent);
                break;
            case R.id.layout_review:
                intent = new Intent(this, ReviewActivity.class);
                putDataToIntent(intent);
                startActivity(intent);
                break;
            case R.id.add_review:
                intent = new Intent(this, PostReviewActivity.class);
                putDataToIntent(intent);
                startActivity(intent);
                break;
            case R.id.rating_layout:
                getRating();
                break;
            case R.id.submit_rating:
                Toast.makeText(getApplicationContext(), ((Float) mRating.getRating()).toString(), Toast.LENGTH_LONG).show();
                mRatingDialog.cancel();
                break;
            case R.id.cancel:
                mRatingDialog.cancel();
                break;
        }
    }

    private void putDataToIntent(Intent intent) {
        intent.putExtra(BundleConstants.VENUE_ID, mVenueId);
        intent.putExtra(BundleConstants.VENUE_NAME, mVenueName);
    }

    private void getRating() {
        ImageView cancelImage;
        mRatingDialog.setTitle(getString(R.string.rating));
        mRatingDialog.setContentView(R.layout.layout_rating_dialog);
        mRatingDialog.show();

        TextView ratingText = mRatingDialog.findViewById(R.id.rating_textview);
        ratingText.setText(String.valueOf(mRatingValue));
        ratingText.setTextColor(Color.parseColor(getString(R.string.append_hash) + mRatingColor));

        cancelImage = mRatingDialog.findViewById(R.id.cancel);
        mRating = mRatingDialog.findViewById(R.id.rating);
        mSubmitButton = mRatingDialog.findViewById(R.id.submit_rating);

        cancelImage.setOnClickListener(this);
        mSubmitButton.setOnClickListener(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMapReady = true;
        MapsInitializer.initialize(getApplicationContext());
        mGoogleMap = googleMap;
    }
}