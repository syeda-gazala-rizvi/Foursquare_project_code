package com.foursquare.ui.filter;


public class VenueFilter {
    private static final VenueFilter ourInstance = new VenueFilter();
    public static SORT_FILTER sortFilter;

    public static int getTierFilter() {
        return tierFilter;
    }

    public static void setTierFilter(int tierFilter) {
        VenueFilter.tierFilter = tierFilter;
    }

    public static Integer getRadius() {
        return radius;
    }

    public static void setRadius(Integer radius) {
        VenueFilter.radius = radius;
    }

    public static int tierFilter;
    public static Integer radius;

    public enum SORT_FILTER {
        RATING, DISTANCE, POPULAR;
    }

    public enum TIER_FILTER {LOW_PRICE, MODERATE_PRICE, HIGH_PRICE, VERY_HIGH_PRICE;
    }

    public static VenueFilter getInstance() {
        return ourInstance;
    }

    private VenueFilter() {
    }
}
