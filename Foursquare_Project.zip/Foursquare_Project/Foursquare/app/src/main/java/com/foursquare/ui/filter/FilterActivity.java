package com.foursquare.ui.filter;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.foursquare.R;

public class FilterActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {
    private TextView mPopularSortTextView;
    private TextView mDistanceSortTextView;
    private TextView mRatingSortTextView;
    private TextView mTier1TextView;
    private TextView mTier2TextView;
    private TextView mTier3TextView;
    private TextView mTier4TextView;
    private Toolbar mToolbar;
    private EditText mDistanceRadius;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        initViewById();
        initToolbar();
        InitClickListener();

    }

    private void InitClickListener() {
        mPopularSortTextView.setOnClickListener(this);
        mRatingSortTextView.setOnClickListener(this);
        mDistanceSortTextView.setOnClickListener(this);
        mTier1TextView.setOnClickListener(this);
        mTier2TextView.setOnClickListener(this);
        mTier3TextView.setOnClickListener(this);
        mTier4TextView.setOnClickListener(this);
    }

    private void initViewById() {
        mPopularSortTextView = findViewById(R.id.popular_sort);
        mDistanceSortTextView = findViewById(R.id.distance_sort);
        mRatingSortTextView = findViewById(R.id.rating_sort);
        mTier1TextView = findViewById(R.id.tier_1);
        mTier2TextView = findViewById(R.id.tier_2);
        mTier3TextView = findViewById(R.id.tier_3);
        mTier4TextView = findViewById(R.id.tier_4);
        mDistanceRadius = findViewById(R.id.distance_radius);

        mDistanceRadius.addTextChangedListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

//            case R.id.popular_sort:
//                setSortFilterTextViewBackground(true, false, false);
//                Application.setSortFilter(Application.SORT_FILTER.POPULAR);
//                break;
//
//            case R.id.distance_sort:
//                setSortFilterTextViewBackground(false, true, false);
//                Application.setSortFilter(Application.SORT_FILTER.DISTANCE);
//                break;
//
//            case R.id.rating_sort:
//                setSortFilterTextViewBackground(false, false, true);
//                Application.setSortFilter(Application.SORT_FILTER.RATING);
//                break;

            case R.id.tier_1:
                setTierFilterTextViewBackground(true, false, false, false);
                VenueFilter.setTierFilter(1);
                break;

            case R.id.tier_2:
                setTierFilterTextViewBackground(false, true, false, false);
                VenueFilter.setTierFilter(2);
                break;

            case R.id.tier_3:
                setTierFilterTextViewBackground(false, false, true, false);
                VenueFilter.setTierFilter(3);
                break;

            case R.id.tier_4:
                setTierFilterTextViewBackground(false, false, false, true);
                VenueFilter.setTierFilter(4);
                break;
        }
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);
            default:
                break;
        }
        return true;
    }

    private void setTierFilterTextViewBackground(boolean tier1, boolean tier2, boolean tier3, boolean tier4) {
        onSelectTextViewBackgroundSetter(mTier1TextView, tier1, R.drawable.ruppe_btn1_selected, R.drawable.ruppe_btn1);
        onSelectTextViewBackgroundSetter(mTier2TextView, tier2, R.drawable.ruppe_btn2_selected, R.drawable.ruppe_btn2);
        onSelectTextViewBackgroundSetter(mTier3TextView, tier3, R.drawable.ruppe_btn3_selected, R.drawable.ruppe_btn3);
        onSelectTextViewBackgroundSetter(mTier4TextView, tier4, R.drawable.ruppe_btn4_selected, R.drawable.ruppe_btn4);
    }

    private void setSortFilterTextViewBackground(boolean popular, boolean distance, boolean rating) {
        onSelectTextViewBackgroundSetter(mPopularSortTextView, popular, R.drawable.popular_selected, R.drawable.popular);
        onSelectTextViewBackgroundSetter(mDistanceSortTextView, distance, R.drawable.distance_selected, R.drawable.distance);
        onSelectTextViewBackgroundSetter(mRatingSortTextView, rating, R.drawable.rating_selected, R.drawable.rating);
    }

    private void onSelectTextViewBackgroundSetter(TextView textView, Boolean bool, int onSelectedBackgroundResourceId, int onUnselectedBackgroundResourceId) {
        if (bool) {
            textView.setBackgroundResource(onSelectedBackgroundResourceId);
        } else {
            textView.setBackgroundResource(onUnselectedBackgroundResourceId);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        //Integer radius = (Integer) mDistanceRadius.getText();
        // Application.setRadius(radius);
    }
}
