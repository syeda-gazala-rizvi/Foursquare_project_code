package com.foursquare.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;

import java.util.ArrayList;
import java.util.List;

public class GridAdapter extends BaseAdapter {

    private List<String> mPhotoPrefixes = new ArrayList<>();
    private List<String> mPhotoSuffixes = new ArrayList<>();
    private Context mContext;
    private LayoutInflater mLayoutInflater;


    public GridAdapter(Context context, List<String> prefixList, List<String> suffixList) {

        mPhotoPrefixes = prefixList;
        mPhotoSuffixes = suffixList;
        mContext = context;
    }

    @Override
    public int getCount() {
        return mPhotoPrefixes.size();
    }

    @Override
    public Object getItem(int position) {
        return mPhotoSuffixes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View gridView = convertView;
        if (convertView == null) {
            mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            gridView = mLayoutInflater.inflate(R.layout.custom_photo_grid_layout, null);

        }
        ImageView image = gridView.findViewById(R.id.grid_image);
        Glide.with(image.getContext()).load(mPhotoPrefixes.get(position) + "100x100" + mPhotoSuffixes.get(position)).apply(new RequestOptions().placeholder(R.drawable.background)).into(image);


        return gridView;

    }
}
