package com.foursquare.ui.detail;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.foursquare.R;
import com.foursquare.constants.BundleConstants;
import com.foursquare.networks.model.review.ReviewDetail;
import com.foursquare.networks.model.review.Tips;
import com.foursquare.networks.model.review.User;
import com.foursquare.networks.retrofit.ApiCall;
import com.foursquare.networks.retrofit.ApiInterface;
import com.foursquare.ui.adapter.ReviewAdapter;
import com.foursquare.ui.home.onRecycleViewClickListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.foursquare.constants.ApiConstants.LAT_LONG;
import static com.foursquare.constants.ApiConstants.OAUTH_TOKEN;
import static com.foursquare.constants.ApiConstants.V;
import static com.foursquare.constants.BundleConstants.VENUE_ID;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;
import static com.foursquare.utils.Util.isNetworkConnectionAvailable;

public class ReviewActivity extends AppCompatActivity implements Callback<ReviewDetail>, onRecycleViewClickListener {

    private List<String> mReviewList = new ArrayList<>();
    private List<User> mUserList = new ArrayList<>();
    private RecyclerView mVenueRecyclerView;
    private ReviewAdapter mReviewAdapter;
    private View mErrorLayout;
    private TextView mErrorTextView;
    private ProgressBar mLoadingProgressBar;
    private OnFragmentInteractionListener mListener;
    private String mVenueId;
    private String mVenueName;
    private Tips mVenueTips;
    private Toolbar mToolbar;
    private ImageView mToolbarImage;
    private TextView mToolbarTitle;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        init();
        initToolbar();
        getVenueId();
        setToolbar();
        getVenueDetails();
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);

        mToolbarImage = mToolbar.findViewById(R.id.toolbar_image);
        mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

    }

    private void setToolbar() {
        mToolbarImage.setVisibility(View.GONE);
        mToolbarTitle.setVisibility(View.VISIBLE);
        mToolbarTitle.setText(mVenueName);
    }

    private void getVenueId() {
        mVenueId = getIntent().getStringExtra(VENUE_ID);
        mVenueName = getIntent().getStringExtra(VENUE_NAME);
    }


    @Override
    public void onResponse(Call<ReviewDetail> call, Response<ReviewDetail> response) {
        if (response.isSuccessful() && response.body() != null) {
            mErrorLayout.setVisibility(View.GONE);
            fetchReviews(response);
        } else {
            displayError(R.string.data_fetching_error, false);
        }
    }

    private void fetchReviews(Response<ReviewDetail> response) {
        if (response.body() != null && response.body().getResponse() != null && response.body().getResponse().getTips() != null) {
            mVenueTips = response.body().getResponse().getTips();
            if (mVenueTips.getItems().size() != 0) {
                for (int i = 0; i < mVenueTips.getItems().size(); i++) {
                    mReviewList.add(mVenueTips.getItems().get(i).getText());
                    mUserList.add(mVenueTips.getItems().get(i).getUser());
                }
                mReviewAdapter.notifyDataSetChanged();

            } else {
                displayError(R.string.Reviews_not_Available, false);
            }
        } else {
            displayError(R.string.failed_to_fetch_data, false);
        }

    }


    @Override
    public void onFailure(Call<ReviewDetail> call, Throwable t) {

    }

    private void getVenueDetails() {
        if (isNetworkConnectionAvailable(Objects.requireNonNull(getApplicationContext()))) {
            displayError(R.string.loading, true);

            ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
            Call<ReviewDetail> venueDetailsCall = apiInterface.getVenueReviews(mVenueId, OAUTH_TOKEN, V, LAT_LONG);
            venueDetailsCall.enqueue(this);
        } else {
            displayError(R.string.network_error, false);
        }
    }

    private void init() {
        initViewById();
        mReviewAdapter = new ReviewAdapter(this, mReviewList, mUserList);
        setRecycleView();
    }

    private void setRecycleView() {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mVenueRecyclerView.setLayoutManager(mLayoutManager);
        mVenueRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mVenueRecyclerView.setAdapter(mReviewAdapter);
    }

    private void initViewById() {
        mVenueRecyclerView = findViewById(R.id.review_recycler_view);
        mErrorLayout = findViewById(R.id.error_layout);
        mErrorTextView = mErrorLayout.findViewById(R.id.error_message);
        mLoadingProgressBar = mErrorLayout.findViewById(R.id.progressBar);
    }

    private void displayError(int errorStringId, Boolean bool) {
        mErrorLayout.setVisibility(View.VISIBLE);
        mErrorTextView.setText(errorStringId);
        if (!bool) {
            mLoadingProgressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_review, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {

            case R.id.review:
                intent = new Intent(this, PostReviewActivity.class);
                intent.putExtra(BundleConstants.VENUE_ID, mVenueId);
                intent.putExtra(BundleConstants.VENUE_NAME, mVenueName);
                startActivity(intent);
                return true;
            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void launchDetailActivity(View view, int position) {

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
