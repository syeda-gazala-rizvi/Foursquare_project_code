package com.foursquare.ui.favourites;

import com.foursquare.networks.model.sub.Venue;

import java.util.ArrayList;
import java.util.List;

public class FavouriteVenues {
    private static final FavouriteVenues ourInstance = new FavouriteVenues();
    public  static List<Venue> favouritesList = new ArrayList<>();

    public static FavouriteVenues getInstance() {
        return ourInstance;
    }

    private FavouriteVenues() {
    }
}
