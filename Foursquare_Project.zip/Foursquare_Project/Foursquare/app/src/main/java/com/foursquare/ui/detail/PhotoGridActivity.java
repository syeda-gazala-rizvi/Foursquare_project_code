package com.foursquare.ui.detail;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.foursquare.R;
import com.foursquare.constants.BundleConstants;
import com.foursquare.networks.model.photos.VenuePhotos;
import com.foursquare.networks.retrofit.ApiCall;
import com.foursquare.networks.retrofit.ApiInterface;
import com.foursquare.ui.adapter.GridAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


import static com.foursquare.constants.ApiConstants.LAT_LONG;
import static com.foursquare.constants.ApiConstants.OAUTH_TOKEN;
import static com.foursquare.constants.ApiConstants.V;
import static com.foursquare.constants.BundleConstants.VENUE_ID;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;
import static com.foursquare.utils.Util.isNetworkConnectionAvailable;


public class PhotoGridActivity extends AppCompatActivity implements Callback<VenuePhotos> {

    private Toolbar mToolbar;
    private ImageView mToolbarImage;
    private TextView mToolbarTitle;
    private GridView gridView;
    private List<String> mPhotoPrefixes = new ArrayList<>();
    private List<String> mPhotoSuffixes = new ArrayList<>();
    private String mVenueId;
    private String mVenueName;
    private View mErrorLayout;
    private TextView mErrorTextView;
    private ProgressBar mLoadingProgressBar;
    private com.foursquare.networks.model.photos.Photos mPhotos;

    private OnFragmentInteractionListener mListener;

    public PhotoGridActivity() {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_photo_grid);

        getVenueId();
        initViews();
        setToolbar();
        showImages();
        enlargeViewPhotos();
    }

    private void setToolbar() {
        mToolbarImage.setVisibility(View.GONE);
        mToolbarTitle.setVisibility(View.VISIBLE);
        mToolbarTitle.setText(mVenueName);
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);

        mToolbarImage = mToolbar.findViewById(R.id.toolbar_image);
        mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu_camera, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.photo:
                Toast.makeText(this, R.string.clicked, Toast.LENGTH_LONG).show();
                return true;
            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }


    private void enlargeViewPhotos() {
        final Intent intent = new Intent(this, EnlargedPhotoActivity.class);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BundleConstants.photoItem = mPhotos;
                BundleConstants.position = position;

                intent.putExtra(BundleConstants.VENUE_ID, mVenueId);
                intent.putExtra(BundleConstants.VENUE_NAME, mVenueName);
                startActivity(intent);
            }
        });
    }

    private void showImages() {
        if (isNetworkConnectionAvailable(Objects.requireNonNull(getApplicationContext()))) {
            displayError(R.string.loading, true);

            ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
            Call<VenuePhotos> venueDetailsCall = apiInterface.getVenuePhotos(mVenueId, OAUTH_TOKEN, V, LAT_LONG);
            venueDetailsCall.enqueue(this);
        } else {
            displayError(R.string.network_error, false);
        }

    }

    private void displayError(int errorStringId, Boolean bool) {
        mErrorLayout.setVisibility(View.VISIBLE);
        mErrorTextView.setText(errorStringId);
        if (!bool) {
            mLoadingProgressBar.setVisibility(View.GONE);
        }
    }

    private void getVenueId() {
        mVenueId = getIntent().getStringExtra(VENUE_ID);
        mVenueName = getIntent().getStringExtra(VENUE_NAME);
    }


    private void initViews() {
        initToolbar();

        gridView = findViewById(R.id.photo_grid);
        mErrorLayout = findViewById(R.id.error_layout);
        mErrorTextView = mErrorLayout.findViewById(R.id.error_message);
        mLoadingProgressBar = mErrorLayout.findViewById(R.id.progressBar);
    }


    @Override
    public void onResponse(Call<VenuePhotos> call, Response<VenuePhotos> response) {

        if (response.isSuccessful() && response.body() != null) {
            mErrorLayout.setVisibility(View.GONE);
            try {
                mPhotos = response.body().getResponse().getPhotos();
            } catch (Exception exception) {
                displayError(R.string.photos_not_available, false);
            }

            try {
                displayPhotos();
            } catch (Exception exception) {
                displayError(R.string.data_fetching_error, false);
            }
        } else
            Toast.makeText(getApplicationContext(), R.string.failed_to_fetch_data, Toast.LENGTH_SHORT).show();

    }

    private void displayPhotos() {
        mPhotoPrefixes.clear();
        mPhotoSuffixes.clear();
        if (mPhotos.getCount() != 0) {
            for (int i = 0; i < (mPhotos.getItems()).size(); i++) {
                mPhotoPrefixes.add(mPhotos.getItems().get(i).getPrefix());
                mPhotoSuffixes.add(mPhotos.getItems().get(i).getSuffix());
            }

            GridAdapter gridAdapter = new GridAdapter(getApplicationContext(), mPhotoPrefixes, mPhotoSuffixes);
            gridView.setAdapter(gridAdapter);
        } else
            displayError(R.string.photos_not_available, false);
    }

    @Override
    public void onFailure(Call<VenuePhotos> call, Throwable t) {

    }
    
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
