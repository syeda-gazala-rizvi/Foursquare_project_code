package com.foursquare.ui.adapter;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.foursquare.ui.home.CoffeeFragment;
import com.foursquare.ui.home.LunchFragment;
import com.foursquare.ui.home.MapFragment;
import com.foursquare.ui.home.NearYouFragment;
import com.foursquare.ui.home.PopularFragment;
import com.foursquare.ui.home.TopPickFragment;

import java.util.ArrayList;

public class MainPagerAdapter extends FragmentStatePagerAdapter {

    private ArrayList<String> mFragmentTitleList;

    public MainPagerAdapter(FragmentManager fm, ArrayList<String> fragmentTitle) {
        super(fm);
        mFragmentTitleList = fragmentTitle;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new NearYouFragment();

            case 1:
                return new TopPickFragment();

            case 2:
                return new PopularFragment();

            case 3:
                return new LunchFragment();

            case 4:
                return new CoffeeFragment();

            default:
                return null;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mFragmentTitleList.get(position);
    }

    @Override
    public int getCount() {
        return mFragmentTitleList.size();
    }
}
