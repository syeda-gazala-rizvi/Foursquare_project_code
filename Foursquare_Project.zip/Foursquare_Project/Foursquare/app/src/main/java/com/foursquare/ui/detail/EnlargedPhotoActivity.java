package com.foursquare.ui.detail;

import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;
import com.foursquare.networks.model.photos.Item_;
import com.foursquare.networks.model.photos.User;

import static com.foursquare.constants.ApplicationConstants.USER_ICON_SIZE;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;
import static com.foursquare.constants.BundleConstants.photoItem;
import static com.foursquare.constants.BundleConstants.position;


public class EnlargedPhotoActivity extends AppCompatActivity {

    Matrix matrix = new Matrix();
    Float scale = 1f;
    ScaleGestureDetector scaleGestureDetector;
    private OnFragmentInteractionListener mListener;
    private android.support.v7.widget.Toolbar mToolbar;
    private ImageView mToolbarImage;
    private TextView mToolbarTitle;
    private ImageView mEnlargedImage;
    private ImageView mUserIcon;
    private TextView mUserName;
    private View mErrorLayout;
    private TextView mErrorTextView;
    private ProgressBar mLoadingProgressBar;
    private String mVenueName;

    public EnlargedPhotoActivity() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_enlarged_photo);

        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListner());

        getVenueId();
        initViews();
        setToolbar();
        setImage();
    }

    private void getVenueId() {
        //String venueId = getIntent().getStringExtra(VENUE_ID);
        mVenueName = getIntent().getStringExtra(VENUE_NAME);
    }

    private void setToolbar() {
        mToolbarImage.setVisibility(View.GONE);
        mToolbarTitle.setVisibility(View.VISIBLE);
        mToolbarTitle.setText(mVenueName);
    }

    private void setImage() {
        try {

            Item_ selectedPhotoItem = photoItem.getItems().get(position);
            User user = selectedPhotoItem.getUser();

            String prifix = selectedPhotoItem.getPrefix();
            String suffix = selectedPhotoItem.getSuffix();

            Glide.with(mEnlargedImage.getContext()).load(prifix + selectedPhotoItem.getWidth() + "x" + selectedPhotoItem.getHeight() + suffix).apply(new RequestOptions().placeholder(R.drawable.background)).into(mEnlargedImage);


            mErrorLayout.setVisibility(View.GONE);
            prifix = user.getPhoto().getPrefix();
            suffix = user.getPhoto().getSuffix();

            Glide.with(mUserIcon.getContext()).load(prifix + USER_ICON_SIZE + suffix).apply(new RequestOptions().placeholder(R.drawable.background).circleCrop().override(150, 150)).into(mUserIcon);

            mUserName.setText(String.format("%s %s", user.getFirstName(), user.getLastName()));


        } catch (Exception exception) {
            displayError(R.string.network_error, false);
        }
    }

    private void displayError(int errorStringId, Boolean bool) {
        mErrorLayout.setVisibility(View.VISIBLE);
        mErrorTextView.setText(errorStringId);
        if (!bool) {
            mLoadingProgressBar.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        initToolbar();

        mEnlargedImage = findViewById(R.id.enlarged_image);
        mUserIcon = findViewById(R.id.user_icon);
        mUserName = findViewById(R.id.userInfo);
        //error status
        mErrorLayout = findViewById(R.id.error_layout);
        mErrorTextView = mErrorLayout.findViewById(R.id.error_message);
        mLoadingProgressBar = mErrorLayout.findViewById(R.id.progressBar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu_share, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.share:
                Toast.makeText(this, R.string.clicked, Toast.LENGTH_LONG).show();
                return true;
            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);

        mToolbarImage = mToolbar.findViewById(R.id.toolbar_image);
        mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    public class ScaleListner extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            scale = scale * detector.getScaleFactor();
            scale = Math.max(0.1f, Math.min(scale, 5f));
            matrix.setScale(scale, scale);
            mEnlargedImage.setImageMatrix(matrix);
            return true;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }
}
