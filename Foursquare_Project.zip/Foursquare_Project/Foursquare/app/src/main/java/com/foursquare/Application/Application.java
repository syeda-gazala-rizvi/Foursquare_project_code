package com.foursquare.Application;

import com.foursquare.networks.model.sub.Venue;


