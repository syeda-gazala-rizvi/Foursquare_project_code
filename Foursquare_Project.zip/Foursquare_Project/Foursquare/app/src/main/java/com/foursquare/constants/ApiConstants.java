package com.foursquare.constants;

public class ApiConstants {
    public static final String BASE_URL = "https://api.foursquare.com/v2/venues/";
    public static final String CLIENT_ID = "RWLSHGZNHQD0YOTEQRLY4F5HTBWSBEDXXJWQSOUQ1OASEASE";
    public static final String CLIENT_SECRET = "B5WYNEMSOSXFQ133JMACUF4DE5CRLHDAEDRMHFC0PRTKA4JG";
    public static final Integer V = 20181026;
    public static final String LAT_LONG_UDUPI = "13.34,74.74";
    public static final String OAUTH_TOKEN = "O1KWXHRLPYFVCFHCYLZ4IYVS2FIAPRUYS20KGOSDV4EG2EAI";
    public static final String LUNCH_ID = "52e81612bcbc57f1066b7a00";
    public static final String COFFEE_ID = "4bf58dd8d48988d1e0931735";
    public static final String TOP_PICK = "4d4b7104d754a06370d81259";
    public static final String CLIENT_ID_1 = "RWLSHGZNHQD0YOTEQRLY4F5HTBWSBEDXXJWQSOUQ1OASEASE";
    public static final String CLIENT_SECRET_1 = "B5WYNEMSOSXFQ133JMACUF4DE5CRLHDAEDRMHFC0PRTKA4JG";
    public static final String LAT_LONG_LONDON = "51.507,-0.127";
    public static final String LAT_LONG_JAPAN = "36.20,138.25";
    public static final String LAT_LONG_MUMBAI = "19.07,72.87";
    public static final String LAT_LONG_NY = "40.71,-74";
    public static final double LAT = 13.34;
    public static final double LNG = 74.74;
    public static final String LAT_LONG = LAT_LONG_MUMBAI;

}
//map api key:   AIzaSyBQWIkj8tUA-YcImLa7SwCXIgBK-MveVCk 