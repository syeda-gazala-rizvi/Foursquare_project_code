
package com.foursquare.networks.model.main;

import com.foursquare.networks.model.sub.Meta;
import com.foursquare.networks.model.sub.TopResponse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TopVenueData {

    @SerializedName("meta")
    @Expose
    private Meta meta;
    @SerializedName("response")
    @Expose
    private TopResponse response;

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public TopResponse getResponse() {
        return response;
    }

    public void setResponse(TopResponse response) {
        this.response = response;
    }

}
