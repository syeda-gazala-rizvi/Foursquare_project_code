package com.foursquare.ui.home;

import android.view.View;

public interface onRecycleViewClickListener {
    void launchDetailActivity(View view, int position);

    //void setFavouriteVenue(int position);
}
