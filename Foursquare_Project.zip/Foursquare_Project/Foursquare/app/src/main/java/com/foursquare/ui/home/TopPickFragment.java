package com.foursquare.ui.home;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.foursquare.R;
import com.foursquare.networks.model.main.LunchVenueData;
import com.foursquare.networks.model.sub.Venue;
import com.foursquare.networks.model.venueDetail.VenueDetails;
import com.foursquare.networks.retrofit.ApiCall;
import com.foursquare.networks.retrofit.ApiInterface;
import com.foursquare.ui.adapter.VenueAdapter;
import com.foursquare.ui.detail.DetailActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.foursquare.constants.ApiConstants.CLIENT_ID;
import static com.foursquare.constants.ApiConstants.CLIENT_SECRET;
import static com.foursquare.constants.ApiConstants.LAT_LONG;
import static com.foursquare.constants.ApiConstants.OAUTH_TOKEN;
import static com.foursquare.constants.ApiConstants.TOP_PICK;
import static com.foursquare.constants.ApiConstants.V;
import static com.foursquare.constants.BundleConstants.VENUE_ID;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;
import static com.foursquare.utils.Util.isNetworkConnectionAvailable;

public class TopPickFragment extends Fragment implements onRecycleViewClickListener {

    private List<Venue> mVenueList = new ArrayList<>();
    private List<String> mVenueIdList = new ArrayList<>();
    private RecyclerView mVenueRecyclerView;
    private VenueAdapter mVenueAdapter;
    private View mErrorLayout;
    private TextView mErrorTextView;
    private ProgressBar mLoadingProgressBar;
    private OnFragmentInteractionListener mListener;

    public TopPickFragment() {
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_top_pick, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        init(view);
        getmVenueList();
    }

    @Override
    public void launchDetailActivity(View view, int position) {
        Intent startNextActivity = new Intent(view.getContext(), DetailActivity.class);
        startNextActivity.putExtra(VENUE_ID, mVenueList.get(position).getId());
        startNextActivity.putExtra(VENUE_NAME, mVenueList.get(position).getName());
        startActivity(startNextActivity);
    }

    private void getmVenueList() {
        if (isNetworkConnectionAvailable(getContext())) {

            displayError(R.string.loading, true);

            ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
            Call<LunchVenueData> topVenueApiCall = apiInterface.getVenuesOnCategories(CLIENT_ID, CLIENT_SECRET, V, LAT_LONG, TOP_PICK);
            topVenueApiCall.enqueue(new Callback<LunchVenueData>() {

                @Override
                public void onResponse(Call<LunchVenueData> call, Response<LunchVenueData> response) {
                    getmVenueIdList(response);
                    getVenueById();

                }

                @Override
                public void onFailure(Call<LunchVenueData> call, Throwable t) {
                    displayError(R.string.data_fetching_error, false);
                }
            });
        } else {
            displayError(R.string.network_error, false);
        }
    }

    private void getVenueById() {
        //if (mVenueIdList.size() != 0){
        if (mVenueIdList.size() > 5) {
            // for (int i = 0; i < mVenueIdList.size(); i++) {
            for (int i = 0; i < 5; i++) {
                ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
                Call<VenueDetails> topVenueDetailApiCall = apiInterface.getVenueDetail(mVenueIdList.get(i), OAUTH_TOKEN, V, LAT_LONG);
                topVenueDetailApiCall.enqueue(new Callback<VenueDetails>() {

                    @Override
                    public void onResponse(Call<VenueDetails> call, Response<VenueDetails> response) {
                        addVenueToList(response);
                    }

                    @Override
                    public void onFailure(Call<VenueDetails> call, Throwable t) {
                        displayError(R.string.data_cannnot_be_fetched, false);
                    }
                });
            }
        }else {
            for (int i = 0; i < mVenueIdList.size(); i++) {
                ApiInterface apiInterface = ApiCall.getInstance().create(ApiInterface.class);
                Call<VenueDetails> nearYouCall = apiInterface.getVenueDetail(mVenueIdList.get(i), OAUTH_TOKEN, V, LAT_LONG);
                nearYouCall.enqueue(new Callback<VenueDetails>() {
                    @Override
                    public void onResponse(Call<VenueDetails> call, Response<VenueDetails> response) {
                        addVenueToList(response);
                    }

                    @Override
                    public void onFailure(Call<VenueDetails> call, Throwable t) {
                        displayError(R.string.data_cannnot_be_fetched, false);
                    }
                });
            }
        }
       /* else{
            displayError(R.string.no_venues, false);
        }*/
    }

    private void addVenueToList(Response<VenueDetails> response) {
        if (response.isSuccessful() && response.body() != null && isAdded()) {
            mErrorLayout.setVisibility(View.GONE);
            mVenueList.add(response.body().getResponse().getVenue());
            mVenueAdapter.notifyDataSetChanged();
        } else {
            displayError(R.string.data_fetching_error, false);
        }
    }

    private void getmVenueIdList(Response<LunchVenueData> response) {
        if (response.isSuccessful() && response.body() != null) {
            for (int i = 0; i < response.body().getResponse().getVenues().size(); i++) {
                mVenueIdList.add(response.body().getResponse().getVenues().get(i).getId());
            }
        }
    }

    private void init(@NonNull View view) {
        initViewById(view);
        mVenueAdapter = new VenueAdapter(this, mVenueList);
        setRecycleView();
    }

    private void setRecycleView() {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        mVenueRecyclerView.setLayoutManager(mLayoutManager);
        mVenueRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mVenueRecyclerView.setAdapter(mVenueAdapter);
    }

    private void initViewById(@NonNull View view) {
        mVenueRecyclerView = (RecyclerView) view.findViewById(R.id.venue_recycler_view);
        mErrorLayout = view.findViewById(R.id.error_layout);
        mErrorTextView = mErrorLayout.findViewById(R.id.error_message);
        mLoadingProgressBar = mErrorLayout.findViewById(R.id.progressBar);
    }

    private void displayError(int errorStringId, Boolean bool) {
        mErrorTextView.setText(errorStringId);
        if (!bool) {
            mLoadingProgressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}