package com.foursquare.networks.retrofit;

import com.foursquare.networks.model.main.LunchVenueData;
import com.foursquare.networks.model.main.TopVenueData;
import com.foursquare.networks.model.main.VenueData;
import com.foursquare.networks.model.photos.VenuePhotos;
import com.foursquare.networks.model.review.ReviewDetail;
import com.foursquare.networks.model.venueDetail.VenueDetails;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("explore")
    Call<TopVenueData> getTrendingPlaces(@Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

    @GET("search")
    Call<LunchVenueData> getVenuesOnCategories(@Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("v") Integer v, @Query("ll") String latLong, @Query("categoryId") String categoryId);

    @GET("{venue_id}")
    Call<VenueDetails> getVenueDetail(@Path("venue_id") String venue_id, @Query("oauth_token") String oauthToken, @Query("v") Integer v, @Query("ll") String latLong);

    @GET("search")
    Call<VenueData> getPlacesNearYou(@Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("v") Integer v, @Query("ll") String latLong);

    @GET("{venue_id}/photos")
    Call<VenuePhotos> getVenuePhotos(@Path("venue_id") String venue_id, @Query("oauth_token") String oauthToken, @Query("v") Integer v, @Query("ll") String latLong);

    @GET("{venue_id}/tips")
    Call<ReviewDetail> getVenueReviews(@Path("venue_id") String venue_id, @Query("oauth_token") String oauthToken, @Query("v") Integer v, @Query("ll") String latLong);

}
/*
********************************** client id
@GET("explore")
    Call<TopVenueData> getTrendingPlaces(@Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

    @GET("search")
    Call<LunchVenueData> getVenuesOnCategories(@Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("v") Integer v, @Query("ll") String latLong, @Query("categoryId") String categoryId);

    @GET("{venue_id}")
    Call<VenueDetails> getVenueDetail(@Path("venue_id") String venue_id, @Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("v") Integer v, @Query("ll") String latLong);

    @GET("search")
    Call<VenueData> getPlacesNearYou(@Query("client_id") String clientId, @Query("client_secret") String clientSecret, @Query("v") Integer v, @Query("ll") String latLong);
****************************************************** oauth token
 @GET("explore")
    Call<TopVenueData> getTrendingPlaces(@Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

    @GET("search")
    Call<LunchVenueData> getVenuesOnCategories(@Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

    @GET("{venue_id}")
    Call<VenueDetails> getVenueDetail(@Path("venue_id") String venue_id, @Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

    @GET("search")
    Call<VenueData> getPlacesNearYou(@Query("ll") String latLong, @Query("oauth_token") String oauthToken, @Query("v") Integer v);

 */