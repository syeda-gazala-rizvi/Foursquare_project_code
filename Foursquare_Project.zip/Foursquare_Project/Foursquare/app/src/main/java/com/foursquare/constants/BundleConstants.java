package com.foursquare.constants;

import com.foursquare.networks.model.photos.Photos;

public class BundleConstants {
    public static final String VENUE_ID = "VenueId";
    public static final String VENUE_NAME = "VenueName";

    public static Photos photoItem;
    public static int position;
}
