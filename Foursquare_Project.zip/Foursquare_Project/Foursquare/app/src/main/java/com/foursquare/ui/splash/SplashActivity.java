package com.foursquare.ui.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.foursquare.R;
import com.foursquare.constants.ApplicationConstants;
import com.foursquare.ui.home.HomeActivity;
import com.foursquare.ui.login.LoginActivity;
import com.foursquare.utils.SessionManager;

import static com.foursquare.constants.ApplicationConstants.FACEBOOK;
import static com.foursquare.constants.ApplicationConstants.GOOGLE;
import static com.foursquare.constants.ApplicationConstants.NORMAL;
import static com.foursquare.constants.ApplicationConstants.SIGN_IN_TYPE;

public class SplashActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT = 3000;
    private Intent mIntent;
    private SessionManager mSessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mSessionManager = new SessionManager(getApplicationContext());

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                if (mSessionManager.isLoggedIn()) {
                    if (mSessionManager.getType().equals(GOOGLE))
                        SIGN_IN_TYPE = ApplicationConstants.SIGNINTYPE.GOOGLE_SIGNIN;
                    else if (mSessionManager.getType().equals(NORMAL))
                        SIGN_IN_TYPE = ApplicationConstants.SIGNINTYPE.NORMAL_SIGNIN;
                    else if (mSessionManager.getType().equals(FACEBOOK))
                        SIGN_IN_TYPE = ApplicationConstants.SIGNINTYPE.FACEBOOK_SIGNIN;

                    mIntent = new Intent(SplashActivity.this, HomeActivity.class);
                } else
                    mIntent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(mIntent);
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}