package com.foursquare.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;
import com.foursquare.constants.ApplicationConstants;
import com.foursquare.ui.adapter.MainPagerAdapter;
import com.foursquare.ui.detail.DetailActivity;
import com.foursquare.ui.filter.FilterActivity;
import com.foursquare.utils.SessionManager;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;

import java.util.ArrayList;
import java.util.HashMap;

import static com.foursquare.constants.ApplicationConstants.ACCOUNT_HOLDER_EMAIL;
import static com.foursquare.constants.ApplicationConstants.ACCOUNT_HOLDER_NAME;
import static com.foursquare.constants.ApplicationConstants.IMAGE_URL;

public class HomeActivity extends AppCompatActivity implements LunchFragment.OnFragmentInteractionListener, NearYouFragment.OnFragmentInteractionListener, CoffeeFragment.OnFragmentInteractionListener, TopPickFragment.OnFragmentInteractionListener, PopularFragment.OnFragmentInteractionListener, NavigationView.OnNavigationItemSelectedListener, GoogleApiClient.OnConnectionFailedListener {

    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private DrawerLayout mDrawer;
    private Toolbar mToolbar;
    private SessionManager mSessionManager;
    private NavigationView mNavigationView;

    private GoogleApiClient mGoogleApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ArrayList<String> FragmentTitleList = new ArrayList<>();

        initViewById();
        inflateMenu();
        drawerAction();
        addTabTitle(FragmentTitleList);
        setTabs(FragmentTitleList);
        initGoogleSignIn();
        loadSliderInfo();
    }

    private void inflateMenu() {
        if (mSessionManager.isLoggedIn())
            mNavigationView.inflateMenu(R.menu.drawer_menu);
        else
            mNavigationView.inflateMenu(R.menu.drawer_menu_general);
    }

    private void setTabs(ArrayList<String> FragmentTitleList) {
        MainPagerAdapter adapter = new MainPagerAdapter(getSupportFragmentManager(), FragmentTitleList);
        mViewPager.setAdapter(adapter);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    private void initGoogleSignIn() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
    }

    private void loadSliderInfo() {
        View header = mNavigationView.getHeaderView(0);
        ImageView imageView = header.findViewById(R.id.user_icon);
        TextView textView = header.findViewById(R.id.account_name);
        HashMap<String, String> user = mSessionManager.getUserDetails();

        if (ApplicationConstants.SIGN_IN_TYPE == ApplicationConstants.SIGNINTYPE.GOOGLE_SIGNIN) {
            textView.setText(user.get(SessionManager.getKeyUsername()));
            Glide.with(getApplicationContext()).load(user.get(SessionManager.getKeyImageurl())).apply(new RequestOptions().override(200, 200).placeholder(R.drawable.ic_account_circle_white).circleCrop()).into(imageView);
        } else {
            textView.setText(user.get(SessionManager.getKeyEmail()));
        }
    }

    private void drawerAction() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawer, mToolbar, (R.string.nav_open), (R.string.nav_close));
        mDrawer.addDrawerListener(toggle);
        toggle.syncState();
        mNavigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        if (mDrawer.isDrawerOpen(GravityCompat.START))
            mDrawer.closeDrawer(GravityCompat.START);
        else
            super.onBackPressed();
    }

    private void initViewById() {
        initToolbar();
        mTabLayout = findViewById(R.id.tab_layout);
        mViewPager = findViewById(R.id.pager);
        mDrawer = findViewById(R.id.drawer_layout);
        mNavigationView = findViewById(R.id.nav_view);
        mSessionManager = new SessionManager(getApplicationContext());
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);
        setSupportActionBar(mToolbar);
    }

    private void addTabTitle(ArrayList<String> FragmentTitleList) {
        FragmentTitleList.add(getString(R.string.near_you_tab));
        FragmentTitleList.add(getString(R.string.top_pick_tab));
        FragmentTitleList.add(getString(R.string.popular_tab));
        FragmentTitleList.add(getString(R.string.lunch_tab));
        FragmentTitleList.add(getString(R.string.coffee_tab));

    }

    @Override
    public void onFragmentInteraction(Uri uri) {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.filter) {
            Intent getFilterFragment = new Intent(this, FilterActivity.class);
            startActivity(getFilterFragment);
            Toast.makeText(this, R.string.clicked, Toast.LENGTH_LONG).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.favourites:
                intent = new Intent(this, DetailActivity.class);
                startActivity(intent);
                break;
            case R.id.feedback:
                break;
            case R.id.about:
                Toast.makeText(this, R.string.about, Toast.LENGTH_LONG).show();
                break;
            case R.id.logout:
                if (ApplicationConstants.SIGN_IN_TYPE == ApplicationConstants.SIGNINTYPE.GOOGLE_SIGNIN) {
                    googleSignOut();
                    ApplicationConstants.SIGN_IN_TYPE = ApplicationConstants.SIGNINTYPE.NORMAL_SIGNIN;
                }
                mSessionManager.logoutUser();
                finish();
                break;
        }
        mDrawer.closeDrawer(GravityCompat.START);
        return false;
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(this, R.string.something_went_wrong, Toast.LENGTH_LONG).show();
    }

    private void googleSignOut() {
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                    }
                });
    }
}