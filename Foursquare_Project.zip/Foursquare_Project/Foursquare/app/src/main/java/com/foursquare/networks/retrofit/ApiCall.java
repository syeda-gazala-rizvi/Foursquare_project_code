package com.foursquare.networks.retrofit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.foursquare.constants.ApiConstants.BASE_URL;

public class ApiCall {
    private static final ApiCall ourInstance = new ApiCall();
    private static Retrofit mRetrofit;

    public static ApiCall getOurInstance() {
        return ourInstance;
    }

    private ApiCall() {

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        mRetrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public static Retrofit getInstance() {
        return mRetrofit;
    }
}