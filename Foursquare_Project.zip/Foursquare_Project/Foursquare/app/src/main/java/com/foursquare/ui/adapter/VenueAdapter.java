package com.foursquare.ui.adapter;

import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;
import com.foursquare.networks.model.sub.Venue;
import com.foursquare.ui.favourites.FavouriteVenues;
import com.foursquare.ui.home.onRecycleViewClickListener;

import java.text.DecimalFormat;
import java.util.List;

public class VenueAdapter extends RecyclerView.Adapter<VenueAdapter.MyViewHolder> {

    private List<Venue> mVenueList;
    private onRecycleViewClickListener mListener;

    public VenueAdapter(onRecycleViewClickListener listener, List<Venue> venueList) {
        this.mVenueList = venueList;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.venue_card_view, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return mVenueList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private ImageView mVenueIconImageView;
        private TextView mVenueTitleTextView;

        private TextView mVenueRatingTextView;
        private TextView mVenueCountryTextView;
        private TextView mVenueTierTextView;
        private TextView mVenueDistanceTextView;
        private TextView mVenueAddressTextView;
        private ImageView mFavoriteImageView;
        private ImageView mDotImageView;
        private LinearLayout mVenueParentLayout;

        public MyViewHolder(View view) {
            super(view);
            initViewById(view);
        }

        private void initViewById(final View view) {
            mVenueIconImageView = view.findViewById(R.id.venue_icon);
            mVenueTitleTextView = view.findViewById(R.id.venue_title);
            mVenueCountryTextView = view.findViewById(R.id.venue_country);
            mVenueRatingTextView = view.findViewById(R.id.venue_rating);
            mVenueTierTextView = view.findViewById(R.id.venue_tier);
            mVenueDistanceTextView = view.findViewById(R.id.venue_distance);
            mVenueAddressTextView = view.findViewById(R.id.venue_address);
            mFavoriteImageView = view.findViewById(R.id.favorite);
            mDotImageView = view.findViewById(R.id.dot_image);
            mVenueParentLayout = view.findViewById(R.id.adapter_view);
            mFavoriteImageView.setOnClickListener(this);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mListener.launchDetailActivity(view, getAdapterPosition());
                }
            });
        }

        boolean favouriteFlag = true;

        @Override
        public void onClick(View view) {

            switch (view.getId()) {

                case R.id.favorite:
                    if (favouriteFlag) {
                        favouriteFlag = false;
                    } else {
                        mFavoriteImageView.setBackgroundResource(R.drawable.favourite_icon);
                        favouriteFlag = true;
                    }
                    break;
            }

        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Venue venues = mVenueList.get(position);
        if (venues != null) {
            setVenueTitle(holder, venues);
            setVenueTier(holder, venues);
            setVenueRating(holder, venues);
            setVenueCategory(holder, venues);
            setVenueDistance(holder, venues);
            setVenueAddress(holder, venues);
            setVenuePhoto(holder, venues);
        }
    }

    private void setVenuePhoto(@NonNull MyViewHolder holder, Venue venues) {
        if (venues.getBestPhoto() != null && venues.getBestPhoto().getPrefix() != null && venues.getBestPhoto().getSuffix() != null && venues.getBestPhoto().getWidth() != null && venues.getBestPhoto().getHeight() != null) {
            String imageUrl = venues.getBestPhoto().getPrefix() + venues.getBestPhoto().getWidth() + holder.mVenueIconImageView.getContext().getString(R.string.x) + venues.getBestPhoto().getHeight() + venues.getBestPhoto().getSuffix();
            Glide.with(holder.mVenueIconImageView.getContext()).load(imageUrl).apply(new RequestOptions().placeholder(R.drawable.background)).into(holder.mVenueIconImageView);
        } else {
            holder.mVenueIconImageView.setImageResource(R.drawable.background);
        }
    }

    private void setVenueAddress(@NonNull MyViewHolder holder, Venue venues) {
        if (!TextUtils.isEmpty(venues.getLocation().getAddress()) && venues.getLocation() != null && venues.getLocation().getAddress() != null) {
            holder.mVenueAddressTextView.setText(venues.getLocation().getAddress());
        } else {
            setEmptyText(holder.mVenueAddressTextView);
        }
    }

    private void setVenueDistance(@NonNull MyViewHolder holder, Venue venues) {
        if (!TextUtils.isEmpty(venues.getLocation().getDistance().toString())) {
            if (venues.getLocation().getDistance() < 900.00) {
                holder.mVenueDistanceTextView.setText(String.format(holder.mVenueDistanceTextView.getContext().getString(R.string.m), venues.getLocation().getDistance()));
            }else{
                double distance = venues.getLocation().getDistance()/1000;
                holder.mVenueDistanceTextView.setText(String.format(holder.mVenueDistanceTextView.getContext().getString(R.string.km), distance));
            }
        } else {
            setEmptyText(holder.mVenueDistanceTextView);
        }
    }

    private void setVenueCategory(@NonNull MyViewHolder holder, Venue venues) {
        if (!TextUtils.isEmpty(venues.getCategories().get(0).getName()) && venues.getCategories() != null && venues.getCategories().get(0).getName() != null) {
            holder.mVenueCountryTextView.setText(venues.getCategories().get(0).getName());
        } else {
            setEmptyText(holder.mVenueCountryTextView);
        }
    }

    private void setVenueRating(@NonNull MyViewHolder holder, Venue venues) {
        if (venues.getRating() != null && !TextUtils.isEmpty(String.valueOf(venues.getRating()))) {
            holder.mVenueRatingTextView.setText(String.valueOf(venues.getRating()));
            holder.mVenueRatingTextView.setBackgroundColor(Color.parseColor(String.format(holder.mVenueRatingTextView.getContext().getString(R.string.rating_color), venues.getRatingColor())));
        } else {
            setEmptyText(holder.mVenueRatingTextView);
        }
    }

    private void setVenueTier(@NonNull MyViewHolder holder, Venue venues) {
        if (venues.getPrice() != null && venues.getPrice().getCurrency() != null && venues.getPrice().getTier() != null && !TextUtils.isEmpty(String.valueOf(venues.getPrice().getTier()))) {
            String tier = "";
            String currency = venues.getPrice().getCurrency();
            for(int i = 0; i < venues.getPrice().getTier(); i++){
                tier = String.format("%s%s", tier, currency);
            }
            //holder.mVenueTierTextView.setText(String.valueOf(venues.getPrice().getTier()));
            holder.mVenueTierTextView.setText(tier);
        } else {
            setEmptyText(holder.mVenueTierTextView);
            holder.mDotImageView.setVisibility(View.GONE);
        }
    }

    private void setVenueTitle(@NonNull MyViewHolder holder, Venue venues) {
        if (!TextUtils.isEmpty(venues.getName())) {
            holder.mVenueTitleTextView.setText(venues.getName());
        } else {
            setEmptyText(holder.mVenueTitleTextView);
        }
    }

    private void setEmptyText(TextView textView) {
        textView.setText(R.string.empty);
    }
}