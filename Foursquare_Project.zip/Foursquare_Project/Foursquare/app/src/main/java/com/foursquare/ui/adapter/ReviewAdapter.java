package com.foursquare.ui.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.foursquare.R;
import com.foursquare.networks.model.review.User;
import com.foursquare.ui.home.onRecycleViewClickListener;

import java.util.ArrayList;
import java.util.List;

import static com.foursquare.constants.ApplicationConstants.USER_ICON_SIZE;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.MyViewHolder> {


    private onRecycleViewClickListener mContext;
    private List<String> mReviewList;
    private List<User> mUserList;

    public ReviewAdapter(onRecycleViewClickListener context, List<String> ReviewList, List<User> userList) {
        this.mReviewList = ReviewList;
        this.mContext = context;
        this.mUserList = userList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.review_card_view, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return mReviewList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String review = mReviewList.get(position);
        String firstname = mUserList.get(position).getFirstName();
        String imageUrl = mUserList.get(position).getPhoto().getPrefix() + USER_ICON_SIZE + mUserList.get(position).getPhoto().getSuffix();

        if (!TextUtils.isEmpty(review)) {
            holder.mVenueReviewTextView.setText(review);
        } else {
            holder.mVenueReviewTextView.setText(R.string.empty);
        }

        if (!TextUtils.isEmpty(firstname)) {
            holder.mUserNameTextView.setText(firstname);
        } else {
            holder.mUserNameTextView.setText(R.string.empty);
        }

        if (!TextUtils.isEmpty(imageUrl)) {
            Glide.with(holder.mUserIconImageView.getContext()).load(imageUrl).apply(new RequestOptions().placeholder(R.drawable.ic_account_circle).circleCrop().override(150, 150)).into(holder.mUserIconImageView);
        } else {
            holder.mUserIconImageView.setImageResource(R.drawable.ic_account_circle);
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private ImageView mUserIconImageView;
        private TextView mUserNameTextView;
        private TextView mVenueReviewTextView;

        private LinearLayout mVenueParentLayout;

        public MyViewHolder(View view) {
            super(view);
            initViewById(view);
        }

        private void initViewById(final View view) {
            mUserIconImageView = view.findViewById(R.id.user_icon);
            mUserNameTextView = view.findViewById(R.id.user_name);
            mVenueReviewTextView = view.findViewById(R.id.review);
            mVenueParentLayout = view.findViewById(R.id.adapter_view);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mContext.launchDetailActivity(view, getAdapterPosition());
                }
            });
        }
    }
}
