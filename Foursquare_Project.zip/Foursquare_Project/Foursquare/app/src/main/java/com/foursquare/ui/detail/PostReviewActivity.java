package com.foursquare.ui.detail;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.foursquare.R;
import com.foursquare.ui.adapter.AddPhotoAdapter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.foursquare.constants.BundleConstants.VENUE_ID;
import static com.foursquare.constants.BundleConstants.VENUE_NAME;

public class PostReviewActivity extends AppCompatActivity implements View.OnClickListener {

    private Toolbar mToolbar;
    private ImageView mToolbarImage;
    private TextView mToolbarTitle;
    private String mVenueId;
    private String mVenueName;
    private LinearLayout mAddPhtoLayout;
    private ImageView mAddPhotoImageView;
    private List<Bitmap> mAddedImageList = new ArrayList<>();
    private AddPhotoAdapter mAddPhotoAdapter;
    private RecyclerView mAddPhotoRecyclerView;

    private Integer REQUEST_CAMERA = 1, SELECT_FILE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_review);

        initViews();
        getVenueId();
        onClickEvents();
    }

    private void initViews() {
        initToolbar();
        setToolbar();
        initViewVariables();
        setRecycleView();
    }

    private void onClickEvents() {
        mAddPhotoImageView.setOnClickListener(this);
    }

    private void initViewVariables() {
        mAddPhotoImageView = findViewById(R.id.photo);
        mAddPhtoLayout = findViewById(R.id.added_image_layout);
        mAddPhotoAdapter = new AddPhotoAdapter(mAddedImageList);
        mAddPhotoRecyclerView = findViewById(R.id.add_photos_recycler_view);
    }

    private void setRecycleView() {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        mAddPhotoRecyclerView.setLayoutManager(mLayoutManager);
        mAddPhotoRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mAddPhotoRecyclerView.setAdapter(mAddPhotoAdapter);
    }

    private void initToolbar() {
        mToolbar = findViewById(R.id.tool_bar);

        mToolbarImage = mToolbar.findViewById(R.id.toolbar_image);
        mToolbarTitle = mToolbar.findViewById(R.id.toolbar_title);

    }

    private void setToolbar() {
        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void getVenueId() {
        mVenueId = getIntent().getStringExtra(VENUE_ID);
        mVenueName = getIntent().getStringExtra(VENUE_NAME);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.photo:
                addImage();
                break;
        }
    }

    private void addImage() {
        final CharSequence[] items = {getString(R.string.Galary), getString(R.string.camera), getString(R.string.cancel)};
        AlertDialog.Builder builder = new AlertDialog.Builder(PostReviewActivity.this);
        builder.setTitle(R.string.add_image);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (items[which].equals(getString(R.string.camera))) {

                    if (ContextCompat.checkSelfPermission(PostReviewActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        takePhoto();
                    } else {
                        requestPermission(REQUEST_CAMERA);
                    }
                } else if (items[which].equals(getString(R.string.Galary))) {
                    if (ContextCompat.checkSelfPermission(PostReviewActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                        selectPhoto();
                    } else {
                        requestPermission(SELECT_FILE);
                    }
                } else if (items[which].equals(getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void selectPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.select_file)), SELECT_FILE);
    }

    private void takePhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }


    private void requestPermission(int type) {
        if (type == REQUEST_CAMERA) {
            permissionRequestForCamera();
        } else if (type == SELECT_FILE) {
            permissionRequestForMedia();
        }
    }

    private void permissionRequestForMedia() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            alertDialogSelectFile();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, SELECT_FILE);
        }
    }

    private void alertDialogSelectFile() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.permission_needed)
                .setMessage(R.string.permission_media)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions(PostReviewActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, SELECT_FILE);
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create().show();
    }

    private void permissionRequestForCamera() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            alertDialogCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
        }
    }

    private void alertDialogCamera() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.permission_needed)
                .setMessage(R.string.permission_camera)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions(PostReviewActivity.this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create().show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == SELECT_FILE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectPhoto();
            } else
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show();
        } else if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                takePhoto();
            } else
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            if (requestCode == REQUEST_CAMERA) {
                Bundle bundle = data.getExtras();
                final Bitmap temp;
                if (bundle != null) {
                    temp = (Bitmap) bundle.get("data");
                    mAddedImageList.add(temp);
                }
            } else if (requestCode == SELECT_FILE) {

                Uri imageUri = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                    mAddedImageList.add(bitmap);
                } catch (IOException e) {
                    Toast.makeText(this, R.string.something_went_wrong, Toast.LENGTH_LONG).show();
                }
            }
            mAddPhotoAdapter.notifyDataSetChanged();
        } else
            Toast.makeText(this, R.string.something_went_wrong, Toast.LENGTH_LONG).show();
    }

}
